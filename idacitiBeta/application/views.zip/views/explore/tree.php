<div class="tree chart">

	<div id="treemap2" class="left"></div>     

</div>