	<?php require "js_footer.php";?>
</body>
</html>