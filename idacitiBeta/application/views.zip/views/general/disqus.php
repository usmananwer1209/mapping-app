 <?php 
    //$this->load->view('general/disqus_test');
    $this->load->view('general/disqus_prod');