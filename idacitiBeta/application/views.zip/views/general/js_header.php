<!--[if lt IE 9]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->

<script src="<?php echo js_lib('moment.min')."?v=".$this->config->item('plugins_version'); ?>"></script>

