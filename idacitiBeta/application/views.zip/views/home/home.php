<?php
	$folder =   dirname(dirname(__FILE__));
 	require_once $folder."/commun/navbar.php";
 ?>
<div class="page-container row-fluid">
  <?php require_once $folder."/commun/main-menu.php";?>
    <div class="page-content">
      <div class="clearfix"></div>
      <div class="content">

                </div>
              </div>
              
              <div class="col-md-4 col-sm-6">
                <div class="row">

                </div>
                <div class="row">


                </div>

                <div class="row">
                  <!-- BEGIN Latest Sec -->
                  <div class="col-md-12 m-b-20">
                    <div class="widget-item narrow-margin">
                      <!-- start feedwind code -->


                     



                      <!-- end feedwind code -->
                    </div>
                  </div>
                  <!-- END Latest Sec -->
                </div>
              </div>

          </div>
        </div>

      </div>

	  </div><!-- end content -->
 </div>