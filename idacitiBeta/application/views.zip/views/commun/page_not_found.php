<div id="main">
	<h1>Error</h1>
	<p class="center">the page you're requesting doesn't exist, check that you've entred the right url, if you followed a link on the website and found yourself here, please <a href="<?php echo site_url('contact'); ?>">contact</a> us!<br />
	<a href="<?php echo site_url('welcome'); ?>">Go to home page</a>.</p>
</div>